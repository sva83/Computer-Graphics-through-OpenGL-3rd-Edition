# CG-through-OpenGL-3rd-Edition

Einfach dem installGuideWindows.pdf folgen.
32-Bit Dateien können in den Ordner C:\Windows\System32 kopiert werden und 64-Bit nach C:\Windows\SysWOW64. 
Schritte 5+6 penibel einhalten!

Damit die Datei Experimenter.pdf funktioniert, folgendes tun:
ExperimenterSource: Beim Entpacken alle Verzeichnisse aus dem Verzeichnis: C:\OpenGLwrappers\ExperimenterSource\ExperimenterSource verschieben nach:
C:\OpenGLwrappers\ExperimenterSource\ und das nun leere ExperimenterSource Verzeichnis löschen.

In diesem Github Verzeichnis sind schon alle Dateien enthalten die man sonst hätte herunterladen müssen (siehe installGuideWindows.pdf).
Die herausgenommenen Kapitel der vierten Edition (die in der dritten noch enthalten waren) müssen auf der Website https://www.sumantaguha.com/ heruntergeladen werden.

Todo: MS Visual Studio Projekt-Templates hier hochladen
